#ifndef LIB_WEBRTC_RTC_VIDEO_SOURCE_HXX
#define LIB_WEBRTC_RTC_VIDEO_SOURCE_HXX

#include "rtc_types.h"

namespace libwebrtc {

class RTCVideoSource : public RefCountInterface {
 public:
  ~RTCVideoSource() {}
};
}  // namespace libwebrtc

#endif  // LIB_WEBRTC_RTC_VIDEO_SOURCE_HXX
